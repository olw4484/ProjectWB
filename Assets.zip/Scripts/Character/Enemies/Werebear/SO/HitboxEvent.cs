[System.Serializable]
public class HitboxEvent
{
    public string attachBoneName;      
    public string hitboxObjectName;    
    public float startTime;
    public float endTime;
}
