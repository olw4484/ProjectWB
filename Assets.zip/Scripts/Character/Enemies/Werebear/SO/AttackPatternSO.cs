using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewAttackPattern", menuName = "Combat/Attack Pattern", order = 0)]
public class AttackPatternSO : ScriptableObject
{
    [Header("�⺻ ����")]
    public string patternName = "Phase2_DashAttack";
    public float damage = 25f;

    [Header("��Ʈ�ڽ� �̺�Ʈ")]
    public List<HitboxEvent> hitboxEvents;

    [Header("Ÿ�� ����Ʈ / ����")]
    public ParticleSystem hitEffect;
    public AudioClip hitSound;

    public void ExecuteAll(Transform origin)
    {
        foreach (var evt in hitboxEvents)
        {
            GameObject hb = GameObject.Instantiate(evt.hitboxPrefab, origin.position, origin.rotation);
            hb.name = $"Hitbox_{evt.attachBoneName}";
            // TODO: �ʿ�� origin.Find(evt.attachBoneName).position ���� ���� ���̱�
        }

        if (hitEffect != null)
            GameObject.Instantiate(hitEffect, origin.position, origin.rotation);

        if (hitSound != null)
        {
            var audio = origin.GetComponent<AudioSource>();
            if (audio != null)
                audio.PlayOneShot(hitSound);
        }
    }
}
