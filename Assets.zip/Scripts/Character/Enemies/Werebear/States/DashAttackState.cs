using UnityEngine;

public class WerebearDashAttackState : BaseEnemyState
{
    private Transform player;
    private UnityEngine.AI.NavMeshAgent agent;

    private float dashSpeedMultiplier = 2.0f;
    private float dashDuration = 0.8f;
    private float timer = 0f;

    private Vector3 dashTarget;

    public WerebearDashAttackState(WerebearStateMachine stateMachine) : base(stateMachine)
    {
        player = stateMachine.Player;
        agent = stateMachine.Agent;
    }

    public override void Enter()
    {
        Debug.Log("[State] DashAttack ����");

        agent.isStopped = false;

        agent.speed *= dashSpeedMultiplier;

        dashTarget = player.position;
        agent.SetDestination(dashTarget);

        animator.SetTrigger("DashAttackTrigger");

        timer = 0f;
    }

    public override void Update()
    {
        timer += Time.deltaTime;

        if (timer > dashDuration)
        {
            agent.isStopped = true;
            agent.speed /= dashSpeedMultiplier;

            float distance = Vector3.Distance(transform.position, player.position);
            if (distance < 4f)
                stateMachine.SetState(new WerebearAttackState(stateMachine));
            else
                stateMachine.SetState(new WerebearIdleState(stateMachine));
        }
    }

    public override void Exit()
    {
        Debug.Log("[State] DashAttack ����");

        agent.speed /= dashSpeedMultiplier;
        agent.isStopped = false;
    }
}
