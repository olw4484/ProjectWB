using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IStaggerable
{
    void Stagger(float duration);
}