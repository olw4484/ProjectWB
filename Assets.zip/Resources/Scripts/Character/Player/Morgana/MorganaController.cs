using UnityEngine;

[RequireComponent(typeof(Animator), typeof(CharacterController))]
public class MorganaController : PlayerController
{
    [Header("������")]
    public MorganaData data;

}